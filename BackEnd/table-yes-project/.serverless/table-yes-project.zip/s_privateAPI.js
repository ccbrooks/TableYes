
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'chloebro',
  applicationName: 'table-yes-project',
  appUid: 'ghnPmmjPGkSLhjsZ24',
  orgUid: 'ef5717ae-18ab-4741-a54e-bcc458ddc002',
  deploymentUid: 'cca34bbe-05ea-4dd9-9b30-893c9a8f2839',
  serviceName: 'table-yes-project',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'table-yes-project-dev-privateAPI', timeout: 6 };

try {
  const userHandler = require('./api/private.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}